# Changelog

## [1.0.1] - 04/04/2024

### Changed
- Update price to 100$


## [1.0.0] - 04/04/2024

### Added
- Camera Video can be buy on Gadgets Shop
