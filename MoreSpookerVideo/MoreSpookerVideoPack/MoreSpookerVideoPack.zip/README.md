# More Spooker Video

*A mod adding camera video in shop*

## Notes
- Required by all players to work properly!

## Requirements
- BepInEx LTS
